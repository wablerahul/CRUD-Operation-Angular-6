export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: "AIzaSyA30XSRbEALZq31jIAQcvL9LxEbkLouuZo",
    authDomain: "fir-4ee46.firebaseapp.com",
    databaseURL: "https://fir-4ee46.firebaseio.com",
    projectId: "fir-4ee46",
    storageBucket: "fir-4ee46.appspot.com",
    messagingSenderId: "691372109371"
  }
};
